# Obylon 7.0.5 LTS Tester Fixes

This revision keeps the release version at **7.0.5-LTS** and fixes the two tester-reported failures at their source.

## 1. Brain missing on the first reboot after rename

### Observed
After renaming the Windows PC, the first reboot could leave `ObylonBroker.exe` and `ObylonCore.exe` running while the Python Brain was absent. Later reboots worked.

### What the logs actually show
The supplied boot trace does **not** establish that WMI was merely “slow.” It establishes that the `obylonc.exe internal-fingerprint` helper returned non-zero while early boot was in progress:

- first helper failure at approximately `21:34:53`
- additional failed probes at approximately 15-second intervals because the Go helper had a 12-second PowerShell/CIM deadline plus retry delay
- the fingerprint finally became available around `21:35:34`
- only then did identity become `READY` and the remainder of Brain initialization proceed

The important root cause is therefore **synchronous dependency on a slow/transient fingerprint provider during Brain startup**, not the hostname rename itself. The hostname is not part of the machine fingerprint.

### Fix
Hardware identity verification is now a **security gate but not a Brain boot gate**:

- The fingerprint helper runs in a dedicated identity-verifier thread.
- The main Brain startup path performs a zero-wait cache check and immediately continues when no fingerprint is available yet.
- The endpoint can bring up session/authentication, heartbeat, detection, and Realtime C2 while Core remains `security-pending`.
- Once a valid fingerprint is obtained, the verifier compares it with the activation fingerprint and signals Core `brain_security_ready` only after a successful match.
- A confirmed mismatch remains terminal and fail-closed (`exit 78`).
- A transient/unavailable helper **never** becomes a clone verdict and never blocks Brain startup for tens of seconds.
- The verified fingerprint is reconciled into the workstation identity after it becomes available, covering the race where registration completed before verification.

This preserves the security boundary while removing the startup stall.

## 2. Shutdown taking 20+ seconds

### What the logs/source show
The command path was already **Realtime C2**. Shutdown latency was not caused by falling back to the normal 1-second action polling loop in the primary path.

The previous terminate implementation had an explicit grace delay before shutdown and then launched the Windows command through a subprocess. That created avoidable command-path latency.

### Fix
- Removed the artificial shutdown grace delay from `controlled_shutdown()`.
- The primary path remains `Realtime -> Brain -> Core IPC`.
- Core now uses the native Win32 `ExitWindowsEx(EWX_POWEROFF | EWX_FORCE, 0)` path directly, avoiding shell/process creation on the critical path.
- `shutdown.exe /s /f /t 0` remains as a compatibility fallback if the native call is rejected.
- Evidence capture remains best-effort and independent of the shutdown control request.
- The action is only acknowledged after the real Core dispatch path accepts it.

This specifically removes Oblyon's own avoidable delay. The remaining time, if any, is Windows' actual shutdown sequence rather than an artificial Obylon sleep or polling wait.

## Additional latency/reliability hardening retained in this build

- Exact Brain PID authorization replaced per-command full process-tree snapshots in Core IPC.
- Named-pipe busy retry is 100 ms instead of 1000 ms, with shorter fallback sleeps.
- IPC deadlines use `time.monotonic()`.
- Foreground telemetry is change-driven instead of writing the same window/process to the database every scan tick.
- Remote configuration polling is 10 seconds; the **security detection scan remains 1 second**.
- Admin action claims have a 30-second lease so crashed dispatch workers cannot permanently strand an action.

## Validation performed in source environment

- Python tests: **37 passed**
- Python compileall: **pass**
- Python AST parse: **pass**
- Go tests (`obylonc`): **pass**
- Rust Windows binary compilation: not performed in this Linux container because Cargo/Windows target tooling is unavailable here.

The release version remains **7.0.5-LTS**. Build the Windows Core/Broker binaries and final installer from this exact source before deployment.
